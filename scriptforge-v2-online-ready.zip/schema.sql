-- Jalankan SQL ini di Supabase SQL Editor.
create table if not exists public.scripts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  game text not null,
  version text not null default '1.0.0',
  category text default 'Script',
  description text default '',
  code text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.scripts enable row level security;

-- Publik boleh membaca script.
create policy "Public can read scripts"
on public.scripts for select
to anon, authenticated
using (true);

-- Hanya user yang login boleh insert/update/delete.
create policy "Authenticated can insert scripts"
on public.scripts for insert
to authenticated
with check (true);

create policy "Authenticated can update scripts"
on public.scripts for update
to authenticated
using (true) with check (true);

create policy "Authenticated can delete scripts"
on public.scripts for delete
to authenticated
using (true);

-- Opsional: realtime agar library dapat menerima perubahan tanpa refresh.
alter table public.scripts replica identity full;
alter publication supabase_realtime add table public.scripts;
