# ScriptForge V2 — Online Ready

## Fitur
- Home / landing page
- Public Script Library
- Search + game filter
- Detail script + Copy
- Admin Login via Supabase Auth
- CRUD script (create/read/update/delete)
- Database PostgreSQL via Supabase
- Realtime library updates
- Bisa di-host gratis di GitHub Pages / Cloudflare Pages / Netlify

## Setup Supabase
1. Buat project di Supabase.
2. Buka SQL Editor dan jalankan `schema.sql`.
3. Buka Authentication > Users dan buat user admin.
4. Ambil Project URL dan anon/public key dari Project Settings > API.
5. Isi keduanya di `config.js`.
6. Upload semua file ke hosting statis.

## Penting
`config.js` hanya boleh berisi anon/public key. Jangan pernah memasukkan `service_role` key ke frontend.

## Hosting
Semua file ini adalah frontend statis. Setelah Supabase dikonfigurasi, folder ini dapat dipublish ke GitHub Pages, Cloudflare Pages, atau Netlify.
