// GANTI dua nilai ini dengan Project URL dan anon/public key dari Supabase.
// Jangan masukkan service_role key ke website.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
const sb = (window.supabase && SUPABASE_URL.startsWith("http") && !SUPABASE_ANON_KEY.startsWith("YOUR_"))
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
