create table if not exists public.scripts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  game text not null,
  version text not null default '1.0.0',
  category text default 'Script',
  description text default '',
  code text not null,
  published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.scripts enable row level security;

drop policy if exists "public read published scripts" on public.scripts;
create policy "public read published scripts"
on public.scripts for select
using (published = true or auth.role() = 'authenticated');

drop policy if exists "authenticated insert scripts" on public.scripts;
create policy "authenticated insert scripts"
on public.scripts for insert
to authenticated
with check (true);

drop policy if exists "authenticated update scripts" on public.scripts;
create policy "authenticated update scripts"
on public.scripts for update
to authenticated
using (true) with check (true);

drop policy if exists "authenticated delete scripts" on public.scripts;
create policy "authenticated delete scripts"
on public.scripts for delete
to authenticated
using (true);

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

drop trigger if exists scripts_touch_updated_at on public.scripts;
create trigger scripts_touch_updated_at
before update on public.scripts
for each row execute function public.touch_updated_at();
